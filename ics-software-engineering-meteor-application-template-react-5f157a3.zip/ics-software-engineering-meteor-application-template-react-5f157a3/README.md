

For details, please see http://ics-software-engineering.github.io/meteor-application-template-react/